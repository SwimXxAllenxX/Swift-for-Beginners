import UIKit
import Foundation

enum Phone: String{
    case iPhone13Mini
    case iPhoneSE
    case Pixel7
    case nokia
}

func getAllensOpinion(on phone: Phone){
    
    switch phone {
    case .iPhone13Mini:
        print("This is the best phone.")
    case .iPhoneSE:
        print("I dislike this phone.")
    case .Pixel7:
        print("Hardware is great. Android is bad.")
    case .nokia:
        print("Can't be broken.")
//    default:
//
    }
}

getAllensOpinion(on: .iPhone13Mini)

let matchmakingRank=45

func determinePlayerLeague(from rank: Int){
    switch rank{
    case 0:
        print("Play the game to determine your league")
    case 1..<50:
        print("You are in BRONZE league")
    case 50..<100:
        print("You are in SILVER league")
    case 100..<200:
        print("You are in GOLD league")
    default:
        print("You are in a league of your own. We don't know where you are")
    }
}

determinePlayerLeague(from: matchmakingRank)
