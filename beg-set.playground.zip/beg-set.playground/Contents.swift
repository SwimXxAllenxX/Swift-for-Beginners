import UIKit

var ages = [18, 33, 55, 17, 94, 26, 33, 17]

//var agesSet: Set<Int> = []

var agesSet = Set(ages)
//order with duplicates is random
print(agesSet)
agesSet.contains(17)
agesSet.insert(101)
