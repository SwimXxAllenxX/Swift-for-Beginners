import UIKit

enum Phone: String{
    case iPhone13Mini = "This is the best phone."
    case iPhoneSE = "I dislike this phone."
    case Pixel7 = "Hardware is great. Android is fine."
    case nokia = "Can't be broken."
}

func getAllensOpinion(on phone: Phone){
//    if phone == .iPhone13Mini{
//        print()
//    } else if phone == .iPhoneSE {
//        print()
//    } else if phone == .Pixel7 {
//        print()
//    } else {
//        print()
//    }
    print(phone.rawValue)
}
getAllensOpinion(on: .iPhone13Mini)
