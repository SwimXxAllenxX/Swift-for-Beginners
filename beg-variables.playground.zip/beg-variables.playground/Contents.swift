import UIKit

var highScore = 0
highScore=55

let myName="Allen"

var currentActiveUsers = 124

currentActiveUsers = 1458
