import UIKit

let devices: [String: String]=[
    "phone": "iPhone 13 Mini",
    "laptop": "2021 Macbook Pro",
    "tablet": "2020 iPad Air",
    "desktop": "2021 iMac",
]

devices["laptop"]
