import UIKit

var isDarkModeOn=true

//if isDarkModeOn==true{
//    print("That's how it should be.")
//}
//else{
//    print("You are a psyhco.")
//}
var myHighScore=111

if myHighScore > 500{
    print("You're the best")
}else if myHighScore>250{
    print("You're average")
}
else
{
    print("Yikes")
}
