import UIKit

let valueOne: Double=55
let valueTwo: Double=88

let sum = valueOne/valueTwo

//sum = valueOne%valueTwo

if valueOne == valueTwo {
    print("They are equal")
}
if valueOne != valueTwo {
    print("They are not equal")
}
//bang operator is "!" the beginning
var isDarkModeOn = true
if !isDarkModeOn{
    print("It's so bright in here")
}
//operators are the same as in Java

let agesYoung = [3,6,9]
let agesOld = [99, 67]

let allAges = agesYoung+agesOld

print(allAges)
