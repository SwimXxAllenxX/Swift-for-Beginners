import UIKit

struct Developer
{
    var name: String
    var jobTitle: String
    var yearsExp: Int
}

var allen = Developer(name: "Allen", jobTitle: "iOS Engineer", yearsExp: 5)

var joe = allen
joe.name="Joe"
allen.name
