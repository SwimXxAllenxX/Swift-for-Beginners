import UIKit

let allStars=["James","Davis", "Harden", "Doncic", "Leonard"]

for player in allStars where player == "Harden" {
    print(player)
}

var randomInts: [Int] = []
//the dash below is if you don't want to use a var name after for
for _ in 0..<25 {
    let randomNumber = Int.random(in: 0...100)
    randomInts.append(randomNumber)
}
print(randomInts)
