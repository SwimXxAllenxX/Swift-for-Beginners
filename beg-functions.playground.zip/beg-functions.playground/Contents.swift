import UIKit

func printInstructors(name: String)
{
    print(name)
}
printInstructors(name: "Joe")

//->Int is like function type in java
func add(firstNumber: Int, to secondNumber: Int)->Int{
    let sum=firstNumber+secondNumber
    return sum
}
add(firstNumber: 14, to: 100)
