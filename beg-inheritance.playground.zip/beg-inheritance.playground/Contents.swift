import UIKit

class Developer
{
    var name: String?
    var jobTitle: String?
    var yearsExp: Int?
    init(){}
    init(name: String, jobTitle: String, yearsExp: Int)
    {
        self.name =      name
        self.jobTitle =  jobTitle
        self.yearsExp = yearsExp
    }
    func speakName()
    {
        print(name)
    }
    
}
class iOSDeveloper: Developer
{
    var favoriteFramework: String?
    func speakFavoriteFramework()
    {
        if let favoriteFramework = favoriteFramework
        {
            print(favoriteFramework)
        }
        else
        {
            print("I don't have a favorite framework")
        }
        
    }
    override func speakName() {
        print("\(name!)-\(jobTitle!)")
    }
}

let allen = iOSDeveloper(name: "Allen", jobTitle: "iOS Engineer", yearsExp: 5)
allen.speakName()
allen.favoriteFramework="ARKit"
allen.speakFavoriteFramework()

